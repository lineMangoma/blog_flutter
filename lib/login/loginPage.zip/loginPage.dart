import 'package:flutter/material.dart';



class Loginpage extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
        centerTitle: true,
      ),
  body: Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SizedBox(
          width: 300,
          child: TextFormField(
            decoration: InputDecoration(
              labelText: 'Email',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.email),
            ),
          ),
        ),
        SizedBox(height: 20),
        SizedBox(
          width: 300,
          child: TextFormField(
            obscureText: true,
            decoration: InputDecoration(
              labelText: 'Mot de passe',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.lock),
            ),
          ),
          
        ),
        SizedBox(height: 20),
        SizedBox(
          width: 300,
          child: FloatingActionButton(
            onPressed:(){},
         child: Text('Se connecter'),   ),
        ),
         SizedBox(height: 20),
        SizedBox(
          width: 300,
          child: FloatingActionButton(
            onPressed:(){},
         child: Text('Creer un compte'),   ),
        )
    
      ],
    ),
  ),
);
  }
  

}